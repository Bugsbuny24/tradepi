/** @type {import('next').NextConfig} */
const nextConfig = {
  // Uygulama artık /app altında çalışacak:
  basePath: "/app",

  // Vercel + basePath ile asset karışmasın:
  assetPrefix: "/app",

  // İstersen kapatabilirsin:
  reactStrictMode: true,
};

module.exports = nextConfig;
