"use client";

import React from "react";

type Props = {
  chartType?: string;
  title?: string | null;
  data?: Array<{ label: string; value: number }>;
};

export default function ChartViewer({ chartType, title, data }: Props) {
  return (
    <div className="w-full rounded-xl border p-4">
      <div className="mb-2 text-sm opacity-70">{chartType || "chart"}</div>
      <div className="text-lg font-semibold">{title || "Untitled"}</div>
      <pre className="mt-4 text-xs whitespace-pre-wrap break-words">
        {JSON.stringify(data ?? [], null, 2)}
      </pre>
    </div>
  );
}
