"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import ChartViewer from "@/components/ChartViewer";

type Mode = "token" | "chart_id";

type ViewRes = {
  ok: boolean;
  error?: string;
  charged?: number | null;
  chart?: { id: string; title: string | null; chart_type: string };
  settings?: any;
};

type DataRes = {
  ok: boolean;
  error?: string;
  charged?: number | null;
  multiplier?: number | null;
  unit_price?: number | null;
  rows?: { label: string; value: number; sort_order: number }[];
  settings?: any;
};

export default function EmbedRuntime(props: {
  mode: Mode;
  token?: string;
  chartId?: string;
  password?: string;
}) {
  const { mode, token, chartId } = props;

  const [pwd, setPwd] = useState(props.password ?? "");
  const [pwdRequired, setPwdRequired] = useState(false);

  const [view, setView] = useState<ViewRes | null>(null);
  const [data, setData] = useState<DataRes | null>(null);

  const [loadingView, setLoadingView] = useState(true);
  const [loadingData, setLoadingData] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const timer = useRef<any>(null);

  const qs = useMemo(() => {
    const p = new URLSearchParams();
    if (mode === "token" && token) p.set("token", token);
    if (mode === "chart_id" && chartId) p.set("chart_id", chartId);
    if (pwd) p.set("password", pwd);
    return p.toString();
  }, [mode, token, chartId, pwd]);

  function clearTimer() {
    if (timer.current) {
      clearInterval(timer.current);
      timer.current = null;
    }
  }

  async function loadView() {
    setLoadingView(true);
    setErr(null);
    setPwdRequired(false);

    try {
      const res = await fetch(`/api/embed/view?${qs}`, { cache: "no-store" });
      const json = (await res.json()) as ViewRes;

      if (!res.ok || !json.ok) {
        if (json.error === "password_required") {
          setPwdRequired(true);
          setView(null);
          return;
        }
        setErr(json.error || "embed_view_failed");
        setView(null);
        return;
      }

      setView(json);
    } catch (e: any) {
      setErr(e?.message || "embed_view_failed");
      setView(null);
    } finally {
      setLoadingView(false);
    }
  }

  async function loadData() {
    setLoadingData(true);
    setErr(null);

    try {
      const res = await fetch(`/api/embed/data?${qs}`, { cache: "no-store" });
      const json = (await res.json()) as DataRes;

      if (!res.ok || !json.ok) {
        if (json.error === "password_required") {
          setPwdRequired(true);
          setData(null);
          return;
        }
        setErr(json.error || "embed_data_failed");
        setData(null);
        return;
      }

      setData(json);
    } catch (e: any) {
      setErr(e?.message || "embed_data_failed");
      setData(null);
    } finally {
      setLoadingData(false);
    }
  }

  // view reload
  useEffect(() => {
    clearTimer();
    setView(null);
    setData(null);
    loadView();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qs]);

  // data load when view ok
  useEffect(() => {
    if (!view?.ok) return;
    loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view?.ok]);

  // auto refresh
  useEffect(() => {
    clearTimer();
    if (!view?.ok) return;

    const s = view.settings || {};
    const seconds = s.auto_refresh_seconds ?? null;
    if (!seconds || seconds <= 0) return;

    const smart = !!s.smart_refresh;

    timer.current = setInterval(() => {
      if (smart && document.visibilityState !== "visible") return;
      loadData();
    }, seconds * 1000);

    return () => clearTimer();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view?.ok, view?.settings?.auto_refresh_seconds, view?.settings?.smart_refresh, qs]);

  // password UI
  if (pwdRequired) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="w-full max-w-sm rounded-2xl border p-5 space-y-3">
          <div className="text-lg font-semibold">Şifre Gerekli</div>
          <p className="text-sm opacity-70">Bu embed şifreyle korunuyor.</p>

          <input
            className="w-full border rounded-lg px-3 py-2"
            placeholder="Password"
            value={pwd}
            onChange={(e) => setPwd(e.target.value)}
          />

          <button className="w-full px-4 py-2 rounded-lg bg-black text-white" onClick={loadView}>
            Devam
          </button>
        </div>
      </div>
    );
  }

  if (loadingView) return <div className="p-6">Embed yükleniyor…</div>;
  if (err) return <div className="p-6">Embed erişimi yok: {err}</div>;
  if (!view?.ok) return <div className="p-6">Embed erişimi yok.</div>;

  const s = view.settings || {};
  const dark = !!s.dark_mode;
  const border = dark ? "border-white/15" : "border-black/10";
  const bg = dark ? "bg-black text-white" : "bg-white text-black";

  const rows = data?.rows ?? [];

  return (
    <div className={`min-h-screen ${bg}`}>
      <div className="p-4 max-w-4xl mx-auto">
        <div className="mb-3">
          <div className="text-base font-semibold">{view.chart?.title ?? "Embed"}</div>
          {loadingData ? <div className="text-xs opacity-60">Veri güncelleniyor…</div> : null}
        </div>

        <div className={`rounded-2xl border ${border} p-4`}>
          {rows.length ? (
            <ChartViewer chartType={view.chart?.chart_type} title={view.chart?.title} data={rows} />
          ) : (
            <div className="text-sm opacity-70">Veri yok</div>
          )}
        </div>

        {s.export_enabled ? (
          <div className="mt-3 flex gap-2">
            <button
              className="px-3 py-2 rounded-lg border text-sm"
              onClick={() => {
                const blob = new Blob([JSON.stringify(rows, null, 2)], { type: "application/json" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = `snaplogic-${view.chart?.id}.json`;
                a.click();
                URL.revokeObjectURL(url);
              }}
            >
              Export JSON
            </button>
          </div>
        ) : null}

        {!s.remove_watermark ? (
          <div className="mt-3 text-xs opacity-60">
            Powered by <span className="font-medium">SnapLogic</span>
          </div>
        ) : null}
      </div>
    </div>
  );
}
