import type { SnopRow, SnopPoint3D } from "./types";

export function SnopAnalyzer(rows: SnopRow[]) {
  // basit “icat”: büyüme + risk + kategori ağırlığı ile score
  const categoryWeight = (c: string) => {
    if (c.toLowerCase().includes("textile")) return 1.2;
    return 1.0;
  };

  const withScore = rows.map((r, i) => {
    const base = Math.max(0, r.value);
    const w = categoryWeight(r.category);
    const riskPenalty = 1 - Math.min(1, Math.max(0, r.risk ?? 0));
    const score = base * w * (0.7 + 0.3 * riskPenalty);

    return { ...r, _i: i, score };
  });

  const to3D = (): SnopPoint3D[] => {
    // x = zaman, y = score, z = risk
    return withScore.map((r) => {
      const t = Date.parse(r.ts);
      const x = Number.isFinite(t) ? t : Date.now();

      const z = (r.risk ?? 0) * 100;

      return {
        x,
        y: r.score,
        z,
        score: r.score,
        label: `${r.country_from}→${r.country_to} | ${r.category}`,
      };
    });
  };

  const summary = () => {
    const total = withScore.reduce((a, b) => a + b.score, 0);
    const avg = withScore.length ? total / withScore.length : 0;
    return { count: withScore.length, totalScore: total, avgScore: avg };
  };

  return { withScore, to3D, summary };
}
