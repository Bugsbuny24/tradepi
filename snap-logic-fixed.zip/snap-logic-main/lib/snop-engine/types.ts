export type SnopRow = {
  ts: string;          // tarih
  country_from: string;
  country_to: string;
  category: string;    // textile, etc.
  value: number;       // hacim / skor girdisi
  risk?: number;       // 0-1 (opsiyonel)
};

export type SnopPoint3D = {
  x: number; y: number; z: number;
  score: number;
  label: string;
};
