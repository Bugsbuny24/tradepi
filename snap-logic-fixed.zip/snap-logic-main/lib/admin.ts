import { createClient } from "@/lib/supabase/server";

export async function isAdminUser(userId: string) {
  const supabase = await createClient();
  const { data } = await supabase
    .from("profiles")
    .select("i_am_admin")
    .eq("id", userId)
    .maybeSingle();

  return !!data?.i_am_admin;
}
