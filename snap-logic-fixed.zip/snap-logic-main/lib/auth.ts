import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export type AuthedUser = {
  id: string;
  email?: string;
};

export async function getUserOrNull(): Promise<AuthedUser | null> {
  const supabase = await createClient();

  const { data, error } = await supabase.auth.getUser();
  if (error || !data?.user) return null;

  return {
    id: data.user.id,
    email: data.user.email ?? undefined,
  };
}

export async function requireUser(): Promise<AuthedUser> {
  const user = await getUserOrNull();

  // login yoksa -> direkt login sayfasına
  if (!user) redirect("/login");

  return user;
}
