import crypto from "crypto";

export function generateEmbedToken() {
  const raw = crypto.randomBytes(32).toString("hex"); // 64 char
  const prefix = raw.slice(0, 10);
  const hash = crypto.createHash("sha256").update(raw).digest("hex");

  return {
    raw,        // kullanıcıya verilecek
    prefix,     // db index için
    hash,       // db’de saklanacak
  };
}
