// app/lib/quota.ts
import { createClient } from "@/lib/supabase/server";

export type ConsumeMeterArgs = {
  userId: string;
  meter: string;
  amount: number;
  refType?: string | null;
  refId?: string | null;
  meta?: Record<string, any> | null;
};

export async function consumeMeter({
  userId,
  meter,
  amount,
  refType = null,
  refId = null,
  meta = null,
}: ConsumeMeterArgs): Promise<boolean> {
  const supabase = await createClient();

  // DB’de overload var: biz 6 parametreli olanı kullanıyoruz
  const { data, error } = await supabase.rpc("consume_meter", {
    p_user_id: userId,
    p_meter: meter,
    p_amount: BigInt(amount),
    p_ref_type: refType,
    p_ref_id: refId,
    p_meta: meta ?? {},
  });

  if (error) {
    // quota/meter hatasında burada patlatmak mantıklı (ürün davranışına göre değişir)
    throw error;
  }

  return Boolean(data);
}
