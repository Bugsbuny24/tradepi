import EmbedRuntime from "@/components/embed/EmbedRuntime";

export const dynamic = "force-dynamic";

export default function EmbedByTokenPage({
  params,
  searchParams,
}: {
  params: { token: string };
  searchParams: { password?: string };
}) {
  return <EmbedRuntime mode="token" token={params.token} password={searchParams?.password} />;
}
