import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(req: Request) {
  const supabase = await createClient();

  const { data: u } = await supabase.auth.getUser();
  if (!u?.user) return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });

  // 1 API call tüket
  const { data: ok, error: e1 } = await supabase.rpc("consume_meter", {
    p_meter: "api_data",
    p_amount: 1,
    p_ref_type: "api",
    p_ref_id: null,
    p_meta: { route: "/api/data" },
  });

  if (e1) return NextResponse.json({ ok: false, error: e1.message }, { status: 500 });
  if (ok !== true) return NextResponse.json({ ok: false, error: "quota_exceeded" }, { status: 402 });

  // ... burada data fetch / response
  return NextResponse.json({ ok: true });
}
