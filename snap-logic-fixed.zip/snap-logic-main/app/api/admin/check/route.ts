export const dynamic = "force-dynamic";
import { NextResponse } from "next/server";
import { createRouteClient } from "@/lib/supabase/route";

export async function GET() {
  const supabase = createRouteClient();

  const { data: userData } = await supabase.auth.getUser();
  if (!userData.user) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const { data, error } = await supabase.rpc("i_am_admin");

  return NextResponse.json({
    user: userData.user.id,
    isAdmin: data,
    error,
  });
}
