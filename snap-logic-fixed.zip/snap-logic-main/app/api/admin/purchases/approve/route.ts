// app/api/admin/purchases/approve/route.ts
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const intent_id = String(body.intent_id ?? "").trim();
  const note = body.note ? String(body.note) : null;

  if (!intent_id) return NextResponse.json({ error: "Missing intent_id" }, { status: 400 });

  // admin kontrol: admins tablosunda var mı?
  const { data: isAdminRow, error: adminErr } = await supabase
    .from("admins")
    .select("user_id")
    .eq("user_id", user.id)
    .maybeSingle();

  if (adminErr || !isAdminRow) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const { error } = await supabase.rpc("approve_purchase_intent", {
    p_intent_id: intent_id,
    p_note: note,
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true });
}
