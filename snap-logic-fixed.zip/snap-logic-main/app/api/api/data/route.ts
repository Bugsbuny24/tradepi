// app/api/api/data/route.ts
export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const token = url.searchParams.get("token");
    if (!token) return NextResponse.json({ error: "token required" }, { status: 400 });

    const supabase = await createClient();

    // verify_chart_token -> TABLE(token_id, chart_id, owner_id, scope)
    const { data: rows, error: vErr } = await supabase.rpc("verify_chart_token", { p_token: token });
    if (vErr) throw vErr;

    const row = Array.isArray(rows) ? rows[0] : null;
    if (!row?.token_id || !row?.chart_id || !row?.owner_id) {
      return NextResponse.json({ error: "invalid token" }, { status: 401 });
    }

    // sayaç bas
    const { error: bErr } = await supabase.rpc("bump_api_counter", {
      p_token_id: row.token_id,
      p_chart_id: row.chart_id,
      p_owner_id: row.owner_id,
    });
    if (bErr) throw bErr;

    // data ver (istersen başka json döndürür)
    const { data, error } = await supabase.rpc("api_data", { p_token: token });
    if (error) throw error;

    return NextResponse.json(data ?? {}, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}
