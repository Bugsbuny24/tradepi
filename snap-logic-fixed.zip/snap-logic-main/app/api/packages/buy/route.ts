// app/api/packages/buy/route.ts
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

type Body = { code?: string };

async function tryRpcBuyPackage(supabase: any, code: string) {
  // Senin SQL’de arg ismi farklıysa buradan yakalarız.
  const attempts: Array<{ fn: string; args: Record<string, any> }> = [
    { fn: "buy_package", args: { p_code: code } },
    { fn: "buy_package", args: { p_package_code: code } },
    { fn: "buy_package", args: { package_code: code } },
  ];

  let lastError: any = null;

  for (const a of attempts) {
    const { data, error } = await supabase.rpc(a.fn, a.args);
    if (!error) return { data };
    lastError = error;
  }

  throw lastError ?? new Error("buy_package RPC failed");
}

export async function POST(req: Request) {
  const supabase = await createClient();

  const {
    data: { user },
    error: authErr,
  } = await supabase.auth.getUser();

  if (authErr) {
    return NextResponse.json({ error: authErr.message }, { status: 401 });
  }
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  let body: Body = {};
  try {
    body = (await req.json()) as Body;
  } catch {}

  const code = (body.code ?? "").trim();
  if (!code) {
    return NextResponse.json({ error: "Missing package code" }, { status: 400 });
  }

  try {
    // DB tarafında buy_package:
    // - pi_purchases/topups loglar
    // - user_quotas / entitlements günceller
    // (senin fonksiyon öyle tasarlanmış)
    const result = await tryRpcBuyPackage(supabase, code);

    return NextResponse.json({ ok: true, result });
  } catch (e: any) {
    return NextResponse.json(
      { error: e?.message ?? "Purchase failed" },
      { status: 400 }
    );
  }
}
