import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const chartId = searchParams.get("chartId");

  if (!chartId) return NextResponse.json({ ok: false, error: "missing_chartId" }, { status: 400 });

  const supabase = await createClient();

  // settings
  const { data: settings, error: sErr } = await supabase
    .from("embed_settings")
    .select("*")
    .eq("chart_id", chartId)
    .maybeSingle();

  if (sErr) return NextResponse.json({ ok: false, error: sErr.message }, { status: 500 });

  // multiplier
  const { data: multiplier, error: mErr } = await supabase
    .rpc("calculate_embed_multiplier", { p_chart_id: chartId });

  if (mErr) return NextResponse.json({ ok: false, error: mErr.message }, { status: 500 });

  return NextResponse.json({ ok: true, settings: settings ?? null, multiplier: multiplier ?? 1.0 });
}

export async function PUT(req: Request) {
  const body = await req.json().catch(() => null);
  if (!body?.chartId) return NextResponse.json({ ok: false, error: "missing_chartId" }, { status: 400 });

  const supabase = await createClient();

  const payload = {
    chart_id: body.chartId,
    is_public: body.is_public ?? true,
    domain_lock: body.domain_lock ?? null,
    password_hash: body.password_hash ?? null,
    expires_at: body.expires_at ?? null,

    theme_color: body.theme_color ?? null,
    dark_mode: body.dark_mode ?? false,
    remove_watermark: body.remove_watermark ?? false,

    auto_refresh_seconds: body.auto_refresh_seconds ?? null,
    smart_refresh: body.smart_refresh ?? false,
    animations: body.animations ?? true,

    analytics_enabled: body.analytics_enabled ?? false,
    export_enabled: body.export_enabled ?? false,
  };

  // upsert (RLS chart owner policy ile korunuyor)
  const { error: upErr } = await supabase
    .from("embed_settings")
    .upsert(payload, { onConflict: "chart_id" });

  if (upErr) return NextResponse.json({ ok: false, error: upErr.message }, { status: 500 });

  const { data: multiplier, error: mErr } = await supabase
    .rpc("calculate_embed_multiplier", { p_chart_id: body.chartId });

  if (mErr) return NextResponse.json({ ok: false, error: mErr.message }, { status: 500 });

  return NextResponse.json({ ok: true, multiplier: multiplier ?? 1.0 });
}
