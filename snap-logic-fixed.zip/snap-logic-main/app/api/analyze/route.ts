import { NextResponse } from "next/server";
import { SnopAnalyzer } from "@/lib/snop-engine/analyzer";
import type { SnopRow } from "@/lib/snop-engine/types";

export async function POST(req: Request) {
  const rows = (await req.json()) as SnopRow[];
  const engine = SnopAnalyzer(rows);

  return NextResponse.json({
    summary: engine.summary(),
    points: engine.to3D(),
  });
}
