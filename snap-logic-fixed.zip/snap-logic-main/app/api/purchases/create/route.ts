// app/api/purchases/create/route.ts
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const package_code = String(body.package_code ?? "").trim();
  const amount_pi = Number(body.amount_pi ?? 0);
  const txid = String(body.txid ?? "").trim();

  if (!package_code || !txid || !(amount_pi > 0)) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }

  const { data, error } = await supabase.rpc("create_purchase_intent", {
    p_package_code: package_code,
    p_amount_pi: amount_pi,
    p_txid: txid,
  });

  if (error) return NextResponse.json({ error: error.message }, { status: 400 });
  return NextResponse.json({ ok: true, intent_id: data });
}
