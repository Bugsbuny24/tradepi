// app/api/embed/view/route.ts
export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const token = body?.token as string | undefined;

    if (!token) return NextResponse.json({ error: "token required" }, { status: 400 });

    const supabase = await createClient();

    // embed_view(p_token text) -> jsonb
    const { data, error } = await supabase.rpc("embed_view", { p_token: token });
    if (error) throw error;

    return NextResponse.json(data ?? { ok: true }, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}
