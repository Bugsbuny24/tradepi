export const dynamic = "force-dynamic";
import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import crypto from "crypto";

export const runtime = "nodejs";

function randomTokenPlain() {
  return crypto.randomBytes(32).toString("hex"); // 64 chars
}
function sha256Hex(input: string) {
  return crypto.createHash("sha256").update(input, "utf8").digest("hex");
}

export async function POST(req: Request) {
  const admin = createAdminClient();
  const body = await req.json().catch(() => ({}));

  const token_id = body?.token_id as string | undefined;
  if (!token_id) return NextResponse.json({ ok: false, error: "missing_token_id" }, { status: 400 });

  // revoke old token
  const { error: revokeErr } = await admin
    .from("chart_tokens")
    .update({ revoked_at: new Date().toISOString() })
    .eq("id", token_id);

  if (revokeErr) return NextResponse.json({ ok: false, error: revokeErr.message }, { status: 500 });

  // create new token
  const token_plain = randomTokenPlain();
  const token_hash = sha256Hex(token_plain);

  // ✅ prefix artık 10
  const token_prefix = token_plain.slice(0, 10);

  const { data: oldTok, error: oldTokErr } = await admin
    .from("chart_tokens")
    .select("chart_id, user_id, scope")
    .eq("id", token_id)
    .maybeSingle();

  if (oldTokErr) return NextResponse.json({ ok: false, error: oldTokErr.message }, { status: 500 });
  if (!oldTok) return NextResponse.json({ ok: false, error: "token_not_found" }, { status: 404 });

  const { data: created, error: createErr } = await admin
    .from("chart_tokens")
    .insert({
      chart_id: oldTok.chart_id,
      user_id: oldTok.user_id,
      scope: oldTok.scope ?? "embed",
      token_hash,
      token_prefix,
      expires_at: null,
      revoked_at: null,
    })
    .select("id, chart_id, created_at")
    .single();

  if (createErr) return NextResponse.json({ ok: false, error: createErr.message }, { status: 500 });

  return NextResponse.json({
    ok: true,
    token: token_plain,
    token_id: created.id,
    chart_id: created.chart_id,
    created_at: created.created_at,
  });
}
