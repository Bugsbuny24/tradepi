import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function GET(req: Request) {
  const supabase = await createClient();
  const { data: authData } = await supabase.auth.getUser();
  if (!authData?.user) return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const chart_id = searchParams.get("chart_id");
  if (!chart_id) return NextResponse.json({ ok: false, error: "missing_chart_id" }, { status: 400 });

  const { data, error } = await supabase
    .from("chart_tokens")
    .select("id,chart_id,scope,token_prefix,created_at,expires_at,revoked_at")
    .eq("chart_id", chart_id)
    .eq("user_id", authData.user.id)
    .order("created_at", { ascending: false });

  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, items: data ?? [] });
}
