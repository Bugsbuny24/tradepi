// app/api/embed/data/route.ts
export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const token = url.searchParams.get("token");

    if (!token) return NextResponse.json({ error: "token required" }, { status: 400 });

    const supabase = await createClient();

    // api_data(p_token text) -> jsonb
    const { data, error } = await supabase.rpc("api_data", { p_token: token });
    if (error) throw error;

    return NextResponse.json(data ?? {}, { status: 200 });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || "Server error" }, { status: 500 });
  }
}
