import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: authData } = await supabase.auth.getUser();
  if (!authData?.user) return NextResponse.json({ ok: false, error: "unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => null);
  const token_id = body?.token_id as string | undefined;
  if (!token_id) return NextResponse.json({ ok: false, error: "missing_token_id" }, { status: 400 });

  const { error } = await supabase
    .from("chart_tokens")
    .update({ revoked_at: new Date().toISOString() })
    .eq("id", token_id)
    .eq("user_id", authData.user.id);

  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true, revoked: true, token_id });
}
