// app/api/embed/create/route.ts
export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { consumeMeter } from "@/lib/quota";

export async function POST(req: Request) {
  try {
    const user = await requireUser();
    const body = await req.json().catch(() => ({}));
    const chart_id = body?.chart_id as string | undefined;

    if (!chart_id) {
      return NextResponse.json({ error: "chart_id required" }, { status: 400 });
    }

    // quota harca (istersen meter adını değiştirebiliriz)
    await consumeMeter({
      userId: user.id,
      meter: "embed_create",
      amount: 1,
      refType: "chart",
      refId: chart_id,
      meta: { route: "/api/embed/create" },
    });

    const supabase = await createClient();

    // DB function: create_embed_token(p_chart_id, p_scope) -> text
    const { data: token, error } = await supabase.rpc("create_embed_token", {
      p_chart_id: chart_id,
      p_scope: "embed",
    });

    if (error) throw error;

    return NextResponse.json({ token }, { status: 200 });
  } catch (e: any) {
    const msg = e?.message || "Server error";
    const code = msg === "UNAUTHORIZED" ? 401 : 500;
    return NextResponse.json({ error: msg }, { status: code });
  }
}
