// app/e/[id]/export/route.ts
import { NextResponse } from "next/server";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";

export const dynamic = "force-dynamic";

function createPublicSupabase() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !anon) {
    throw new Error("Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY");
  }

  return createSupabaseClient(url, anon, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => fetch(input, { ...(init ?? {}), cache: "no-store" }),
    },
  });
}

function csvEscape(s: string) {
  const x = String(s ?? "");
  if (/[",\n]/.test(x)) return `"${x.replace(/"/g, '""')}"`;
  return x;
}

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const chartId = params.id;
  const supabase = createPublicSupabase();

  // embed settings -> export enabled mi?
  const { data: settings } = await supabase
    .from("embed_settings")
    .select("export_enabled,is_public")
    .eq("chart_id", chartId)
    .maybeSingle();

  // settings yoksa charts fallback
  let exportEnabled = false;
  let isPublic = false;

  if (settings) {
    exportEnabled = Boolean((settings as any).export_enabled);
    isPublic = Boolean((settings as any).is_public);
  } else {
    const { data: chart } = await supabase
      .from("charts")
      .select("is_public")
      .eq("id", chartId)
      .maybeSingle();
    if (!chart) return NextResponse.json({ error: "not_found" }, { status: 404 });
    isPublic = Boolean((chart as any).is_public);
    exportEnabled = false; // settings yoksa default kapalı
  }

  if (!isPublic) return NextResponse.json({ error: "embed_closed" }, { status: 403 });
  if (!exportEnabled) return NextResponse.json({ error: "export_disabled" }, { status: 403 });

  const { data: entries, error } = await supabase
    .from("data_entries")
    .select("label,value,sort_order")
    .eq("chart_id", chartId)
    .order("sort_order");

  if (error) return NextResponse.json({ error: "db_error" }, { status: 500 });

  const rows = (entries as any[]) ?? [];
  const header = ["label", "value", "sort_order"];
  const csv =
    header.join(",") +
    "\n" +
    rows
      .map((r) => [csvEscape(r.label), csvEscape(r.value), csvEscape(r.sort_order)].join(","))
      .join("\n");

  return new NextResponse(csv, {
    status: 200,
    headers: {
      "content-type": "text/csv; charset=utf-8",
      "content-disposition": `attachment; filename="chart-${chartId}.csv"`,
    },
  });
}
