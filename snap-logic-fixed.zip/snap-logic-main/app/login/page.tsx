import { signInWithPasswordAction } from "./actions";

export default async function LoginPage({
  searchParams,
}: {
  searchParams?: { e?: string };
}) {
  const err = searchParams?.e ? decodeURIComponent(searchParams.e) : "";

  return (
    <main className="min-h-screen bg-gradient-to-b from-zinc-950 via-zinc-950 to-zinc-900 text-zinc-100">
      <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center p-6">
        <div className="rounded-2xl border border-zinc-800 bg-zinc-950/60 p-6 shadow-xl">
          <div className="mb-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900/50 px-3 py-1 text-xs text-zinc-300">
              <span className="h-2 w-2 rounded-full bg-emerald-400" />
              Admin Access
            </div>
            <h1 className="mt-4 text-2xl font-semibold tracking-tight">Login</h1>
            <p className="mt-1 text-sm text-zinc-400">
              Email + password ile giriş yap. (Magic link yok.)
            </p>
          </div>

          {err ? (
            <div className="mb-4 rounded-xl border border-red-900/40 bg-red-950/40 px-4 py-3 text-sm text-red-200">
              {err}
            </div>
          ) : null}

          <form action={signInWithPasswordAction} className="space-y-4">
            <label className="block">
              <span className="text-xs text-zinc-400">Email</span>
              <input
                name="email"
                type="email"
                required
                placeholder="onur24sel@gmail.com"
                className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm outline-none ring-0 placeholder:text-zinc-600 focus:border-zinc-600"
              />
            </label>

            <label className="block">
              <span className="text-xs text-zinc-400">Password</span>
              <input
                name="password"
                type="password"
                required
                placeholder="••••••••"
                className="mt-1 w-full rounded-xl border border-zinc-800 bg-zinc-950 px-3 py-2 text-sm outline-none ring-0 placeholder:text-zinc-600 focus:border-zinc-600"
              />
            </label>

            <button
              type="submit"
              className="w-full rounded-xl bg-emerald-500 px-3 py-2 text-sm font-medium text-zinc-950 hover:bg-emerald-400 active:bg-emerald-600"
            >
              Giriş Yap
            </button>

            <p className="text-xs text-zinc-500">
              Giriş sonrası: <b className="text-zinc-300">/admin</b>
            </p>
          </form>
        </div>

        <p className="mt-4 text-center text-xs text-zinc-600">
          tradepigloball.co • SnapLogic Admin
        </p>
      </div>
    </main>
  );
}
