"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

function safeMsg(err: unknown) {
  if (err && typeof err === "object" && "message" in err) {
    return String((err as any).message);
  }
  return "Login failed";
}

export async function signInWithPasswordAction(formData: FormData) {
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");

  if (!email || !password) {
    redirect(`/login?e=${encodeURIComponent("Email ve şifre gerekli")}`);
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    redirect(`/login?e=${encodeURIComponent(safeMsg(error))}`);
  }

  redirect("/admin");
}
