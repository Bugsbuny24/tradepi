// app/apply/page.tsx
import { createClient } from "@/lib/supabase/server";
import PackagesClient from "./packages-client";

export const dynamic = "force-dynamic";

type PackageRow = {
  id: string;
  code: string;
  title: string;
  price_pi: number;
  grants: Record<string, number>;
  is_active: boolean;
  created_at: string;
};

export default async function ApplyPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  // İstersen login zorunlu yap:
  // if (!user) redirect("/login");

  const { data, error } = await supabase
    .from("packages")
    .select("id, code, title, price_pi, grants, is_active, created_at")
    .eq("is_active", true)
    .order("price_pi", { ascending: true });

  const packages: PackageRow[] = (data ?? []) as any;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-semibold">Packages</h1>
        <p className="mt-2 text-sm text-gray-500">
          Embed / NoWater / Widget / API Data paketlerini buradan satın alırsın.
          <br />
          <span className="font-medium">Not:</span> Şimdilik ödeme doğrulama (Pi tx) kısmını
          “manual/onaylı” yapıda kurguluyoruz; satın al butonu quota tanımlarını uygular.
        </p>
      </div>

      {!user && (
        <div className="mb-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm">
          Şu an giriş yapmadın. Paket satın almak için login olman gerekebilir.
        </div>
      )}

      {error && (
        <div className="mb-6 rounded-lg border border-red-200 bg-red-50 p-4 text-sm">
          Paketler çekilemedi: {error.message}
        </div>
      )}

      <PackagesClient packages={packages} />
    </div>
  );
}
