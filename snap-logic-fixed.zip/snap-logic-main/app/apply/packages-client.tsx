"use client";

import { useMemo, useState } from "react";

type PackageRow = {
  id: string;
  code: string;
  title: string;
  price_pi: number;
  grants: Record<string, number>;
  is_active: boolean;
  created_at: string;
};

function formatGrants(grants: Record<string, number>) {
  const entries = Object.entries(grants ?? {});
  if (!entries.length) return "—";
  return entries
    .map(([k, v]) => `${k.replaceAll("_", " ")}: ${Number(v).toLocaleString()}`)
    .join(" • ");
}

export default function PackagesClient({ packages }: { packages: PackageRow[] }) {
  const [loadingCode, setLoadingCode] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);

  const grouped = useMemo(() => {
    // basit gruplama: code prefix'e göre
    const buckets: Record<string, PackageRow[]> = {
      Embed: [],
      NoWater: [],
      Widget: [],
      API: [],
      Other: [],
    };

    for (const p of packages) {
      const c = p.code.toUpperCase();
      if (c.startsWith("EMBED_") || c.startsWith("EMBED")) buckets.Embed.push(p);
      else if (c.startsWith("NOWATER") || c.startsWith("NO_WATER")) buckets.NoWater.push(p);
      else if (c.startsWith("WIDGET")) buckets.Widget.push(p);
      else if (c.startsWith("API")) buckets.API.push(p);
      else buckets.Other.push(p);
    }
    return buckets;
  }, [packages]);

  async function buy(code: string) {
    try {
      setMsg(null);
      setLoadingCode(code);

      const res = await fetch("/api/packages/buy", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ code }),
      });

      const json = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(json?.error ?? `HTTP ${res.status}`);
      }

      setMsg({
        type: "ok",
        text: `Satın alma başarılı: ${code}. Quota’ların güncellendi (Dashboard’dan kontrol et).`,
      });
    } catch (e: any) {
      setMsg({ type: "err", text: e?.message ?? "Satın alma başarısız." });
    } finally {
      setLoadingCode(null);
    }
  }

  return (
    <div className="space-y-10">
      {msg && (
        <div
          className={[
            "rounded-lg border p-4 text-sm",
            msg.type === "ok" ? "border-emerald-200 bg-emerald-50" : "border-red-200 bg-red-50",
          ].join(" ")}
        >
          {msg.text}
        </div>
      )}

      {Object.entries(grouped)
        .filter(([, list]) => list.length > 0)
        .map(([groupName, list]) => (
          <section key={groupName}>
            <div className="mb-3 flex items-end justify-between">
              <h2 className="text-xl font-semibold">{groupName}</h2>
              <div className="text-xs text-gray-500">{list.length} paket</div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {list.map((p) => (
                <div
                  key={p.id}
                  className="rounded-xl border bg-white p-4 shadow-sm"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-sm text-gray-500">{p.code}</div>
                      <div className="mt-1 text-lg font-semibold">{p.title}</div>
                    </div>

                    <div className="rounded-lg bg-gray-100 px-3 py-1 text-sm font-semibold">
                      {Number(p.price_pi).toLocaleString()} PI
                    </div>
                  </div>

                  <div className="mt-3 text-xs text-gray-600">
                    {formatGrants(p.grants)}
                  </div>

                  <button
                    className="mt-4 w-full rounded-lg bg-black px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
                    onClick={() => buy(p.code)}
                    disabled={!!loadingCode}
                  >
                    {loadingCode === p.code ? "İşleniyor..." : "Satın Al"}
                  </button>

                  <div className="mt-2 text-[11px] text-gray-500">
                    Bu buton DB’de <code>buy_package</code> RPC çağırır.
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
    </div>
  );
                  }
