// app/topup/page.tsx
import { createClient } from "@/lib/supabase/server";
import TopupClient from "./topup-client";

export const dynamic = "force-dynamic";

export default async function TopupPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const { data: packages } = await supabase
    .from("packages")
    .select("code,title,price_pi,grants")
    .eq("is_active", true)
    .order("price_pi", { ascending: true });

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="text-3xl font-semibold">Topup (Pi)</h1>
      <p className="mt-2 text-sm text-gray-500">
        Paketi seç, ödeme yaptıysan TXID gir. Admin onaylayınca quota’ların yüklenir.
      </p>

      {!user && (
        <div className="mt-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm">
          Giriş yapmadan topup gönderemezsin.
        </div>
      )}

      <div className="mt-8">
        <TopupClient packages={(packages ?? []) as any} disabled={!user} />
      </div>
    </div>
  );
}
