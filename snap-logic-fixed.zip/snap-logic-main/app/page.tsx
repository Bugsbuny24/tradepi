import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen p-8">
      <div className="mx-auto max-w-3xl space-y-6">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-bold">SnapLogic</span>
          <span className="text-green-600">✅</span>
        </div>

        <h1 className="text-3xl font-semibold leading-tight">
          The Universal Data Visualization Bridge
        </h1>

        <p className="text-sm text-neutral-600">
          Dashboard + Chart Tool + No-Code Builder + SaaS + API Engine.
          Üstüne de ayrı bir modül: <b>Snop-Engine</b> (bizim icat ettiğimiz katman).
        </p>

        <div className="flex gap-3">
          <Link className="underline" href="/login">Login</Link>
          <Link className="underline" href="/dashboard">Dashboard</Link>
          <Link className="underline" href="/apply">Get Premium</Link>
        </div>

        <div className="border rounded-lg p-4">
          <h2 className="font-semibold mb-2">Premium ne veriyor?</h2>
          <ul className="list-disc pl-5 text-sm space-y-1">
            <li>Embed widgets + watermark off</li>
            <li>API call quotas</li>
            <li>No-code chart builder</li>
            <li>Snop-Engine analitik modülleri (ayrı plugin)</li>
          </ul>
        </div>
      </div>
    </main>
  );
}
