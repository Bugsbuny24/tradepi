// app/admin/purchases/purchases-client.tsx
"use client";

import { useState } from "react";

export default function AdminPurchasesClient({
  rows,
}: {
  rows: Array<{
    id: string;
    user_id: string;
    package_code: string;
    amount_pi: number;
    txid: string;
    status: string;
    created_at: string;
  }>;
}) {
  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  async function approve(id: string) {
    setMsg(null);
    setLoadingId(id);
    try {
      const res = await fetch("/api/admin/purchases/approve", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ intent_id: id, note: "approved" }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json?.error ?? "Failed");
      setMsg(`Approved ✅ ${id}`);
      // basit refresh:
      window.location.reload();
    } catch (e: any) {
      setMsg(`Hata: ${e?.message ?? "Unknown"}`);
    } finally {
      setLoadingId(null);
    }
  }

  return (
    <div className="space-y-3">
      {msg && <div className="rounded-lg border p-3 text-sm">{msg}</div>}

      {rows.length === 0 && (
        <div className="rounded-lg border p-4 text-sm text-gray-500">
          Pending yok.
        </div>
      )}

      {rows.map((r) => (
        <div key={r.id} className="rounded-xl border bg-white p-4 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="text-sm">
              <div className="font-semibold">{r.package_code} • {r.amount_pi} PI</div>
              <div className="text-gray-500">user: {r.user_id}</div>
              <div className="text-gray-500">txid: {r.txid}</div>
            </div>

            <button
              onClick={() => approve(r.id)}
              disabled={!!loadingId}
              className="rounded-lg bg-black px-4 py-2 text-sm font-semibold text-white disabled:opacity-60"
            >
              {loadingId === r.id ? "Onaylanıyor..." : "Approve"}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
