// app/admin/purchases/page.tsx
import { createClient } from "@/lib/supabase/server";
import AdminPurchasesClient from "./purchases-client";

export const dynamic = "force-dynamic";

export default async function AdminPurchasesPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return <div className="p-10">Unauthorized</div>;
  }

  const { data: isAdmin } = await supabase
    .from("admins")
    .select("user_id")
    .eq("user_id", user.id)
    .maybeSingle();

  if (!isAdmin) {
    return <div className="p-10">Forbidden</div>;
  }

  const { data } = await supabase
    .from("purchase_intents")
    .select("id,user_id,package_code,amount_pi,txid,status,created_at")
    .eq("status", "pending")
    .order("created_at", { ascending: true });

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <h1 className="text-3xl font-semibold">Admin • Pending Purchases</h1>
      <p className="mt-2 text-sm text-gray-500">
        Pending kayıtları burada onaylayınca quota basılır.
      </p>

      <div className="mt-8">
        <AdminPurchasesClient rows={(data ?? []) as any} />
      </div>
    </div>
  );
}
