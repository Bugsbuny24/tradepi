// app/admin/page.tsx
import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { isAdminUser } from "@/lib/admin";

function cn(...s: (string | false | null | undefined)[]) {
  return s.filter(Boolean).join(" ");
}

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border bg-white/60 px-3 py-1 text-xs backdrop-blur">
      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
      {children}
    </span>
  );
}

function Stat({
  title,
  value,
  hint,
}: {
  title: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border bg-white/70 p-4 shadow-sm backdrop-blur">
      <div className="text-sm text-neutral-500">{title}</div>
      <div className="mt-2 text-2xl font-semibold tracking-tight">{value}</div>
      {hint ? <div className="mt-1 text-xs text-neutral-500">{hint}</div> : null}
    </div>
  );
}

function Table({
  head,
  children,
}: {
  head: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="overflow-hidden rounded-2xl border bg-white/70 shadow-sm backdrop-blur">
      {head}
      <div className="overflow-x-auto">{children}</div>
    </div>
  );
}

export default async function AdminPage() {
  const user = await requireUser();
  const ok = await isAdminUser(user.id);

  if (!ok) {
    return (
      <div className="min-h-[70vh] grid place-items-center p-6">
        <div className="w-full max-w-md rounded-3xl border bg-white/70 p-6 shadow-sm backdrop-blur">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-neutral-500">SnapLogic</div>
              <h1 className="text-xl font-semibold">Admin Access</h1>
            </div>
            <span className="rounded-full border px-3 py-1 text-xs">DENIED</span>
          </div>
          <p className="mt-3 text-sm text-neutral-600">
            Bu sayfa sadece admin kullanıcılar içindir.
          </p>
          <div className="mt-4 flex gap-3">
            <Link className="text-sm underline" href="/dashboard">
              Dashboard
            </Link>
            <Link className="text-sm underline" href="/apply">
              Apply
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const supabase = await createClient();

  const [{ count: usersCount }, { count: chartsCount }] = await Promise.all([
    supabase.from("profiles").select("id", { count: "exact", head: true }),
    supabase.from("charts").select("id", { count: "exact", head: true }),
  ]);

  const { data: logs } = await supabase
    .from("usage_logs")
    .select("user_id, meter, amount, ref_type, created_at")
    .order("created_at", { ascending: false })
    .limit(25);

  const { data: recentUsers } = await supabase
    .from("profiles")
    .select("id, email, created_at")
    .order("created_at", { ascending: false })
    .limit(12);

  return (
    <div className="min-h-screen bg-[radial-gradient(1200px_600px_at_20%_-10%,rgba(16,185,129,0.18),transparent_60%),radial-gradient(900px_500px_at_80%_0%,rgba(59,130,246,0.14),transparent_60%),linear-gradient(to_bottom,rgba(250,250,250,1),rgba(255,255,255,1))]">
      {/* Topbar */}
      <div className="sticky top-0 z-20 border-b bg-white/70 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-2xl border bg-white shadow-sm">
              ⚡
            </div>
            <div>
              <div className="font-semibold leading-tight">SnapLogic Admin</div>
              <div className="text-xs text-neutral-500">Premium control center</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Pill>ADMIN</Pill>
            <span className="hidden md:inline font-mono text-xs text-neutral-500">
              {user.id}
            </span>
            <Link className="rounded-xl border bg-white px-3 py-2 text-sm hover:bg-neutral-50" href="/dashboard">
              Dashboard
            </Link>
          </div>
        </div>
      </div>

      {/* Layout */}
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-4 py-6 lg:grid-cols-[260px_1fr]">
        {/* Sidebar */}
        <aside className="rounded-3xl border bg-white/60 p-4 shadow-sm backdrop-blur">
          <div className="text-xs text-neutral-500">Navigation</div>
          <nav className="mt-3 space-y-2">
            <Link className="block rounded-2xl border bg-white px-3 py-2 text-sm hover:bg-neutral-50" href="/admin">
              Overview
            </Link>
            <Link className="block rounded-2xl border bg-white px-3 py-2 text-sm hover:bg-neutral-50" href="/dashboard">
              User Dashboard
            </Link>
            <Link className="block rounded-2xl border bg-white px-3 py-2 text-sm hover:bg-neutral-50" href="/apply">
              Plans / Apply
            </Link>
            <Link className="block rounded-2xl border bg-white px-3 py-2 text-sm hover:bg-neutral-50" href="/embed">
              Embed Studio
            </Link>
          </nav>

          <div className="mt-6 rounded-2xl border bg-white/70 p-3">
            <div className="text-xs text-neutral-500">Quick Actions</div>
            <div className="mt-2 flex flex-col gap-2">
              <Link className="rounded-xl border bg-white px-3 py-2 text-sm hover:bg-neutral-50" href="/apply">
                + Add package
              </Link>
              <Link className="rounded-xl border bg-white px-3 py-2 text-sm hover:bg-neutral-50" href="/login">
                Login page
              </Link>
            </div>
          </div>
        </aside>

        {/* Main */}
        <main className="space-y-6">
          {/* Hero */}
          <div className="rounded-3xl border bg-white/70 p-6 shadow-sm backdrop-blur">
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <h1 className="text-2xl font-semibold tracking-tight">Control Room</h1>
                <p className="mt-1 text-sm text-neutral-600">
                  Kullanıcılar, chartlar ve kullanım logları.
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <span className="rounded-2xl border bg-white/60 px-3 py-2 text-sm">
                  System: <b>Healthy</b>
                </span>
                <span className="rounded-2xl border bg-white/60 px-3 py-2 text-sm">
                  Mode: <b>Premium</b>
                </span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat title="Total users" value={usersCount ?? 0} />
            <Stat title="Total charts" value={chartsCount ?? 0} />
            <Stat title="Realtime" value="Ready" hint="Supabase realtime friendly" />
            <Stat title="Security" value="Admin-gated" hint="profiles.i_am_admin" />
          </div>

          {/* Recent Users */}
          <Table
            head={
              <div className="flex items-center justify-between border-b p-4">
                <div>
                  <div className="font-semibold">Recent Users</div>
                  <div className="text-xs text-neutral-500">Last 12 signups</div>
                </div>
                <Link className="text-sm underline" href="/dashboard">
                  go dashboard
                </Link>
              </div>
            }
          >
            <table className="w-full text-sm">
              <thead className="bg-neutral-50">
                <tr className="text-left">
                  <th className="px-4 py-3">User</th>
                  <th className="px-4 py-3">Email</th>
                  <th className="px-4 py-3">Created</th>
                </tr>
              </thead>
              <tbody>
                {(recentUsers ?? []).map((u) => (
                  <tr key={u.id} className="border-t">
                    <td className="px-4 py-3 font-mono">{u.id}</td>
                    <td className="px-4 py-3">{u.email ?? "-"}</td>
                    <td className="px-4 py-3 text-neutral-600">
                      {u.created_at ? new Date(u.created_at).toLocaleString() : "-"}
                    </td>
                  </tr>
                ))}
                {(recentUsers ?? []).length === 0 && (
                  <tr>
                    <td className="px-4 py-4" colSpan={3}>
                      Veri yok.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </Table>

          {/* Logs */}
          <Table
            head={
              <div className="flex items-center justify-between border-b p-4">
                <div>
                  <div className="font-semibold">Usage Logs</div>
                  <div className="text-xs text-neutral-500">Last 25 events</div>
                </div>
                <span className="text-xs text-neutral-500">tip: meter/amount</span>
              </div>
            }
          >
            <table className="w-full text-sm">
              <thead className="bg-neutral-50">
                <tr className="text-left">
                  <th className="px-4 py-3">Time</th>
                  <th className="px-4 py-3">User</th>
                  <th className="px-4 py-3">Meter</th>
                  <th className="px-4 py-3">Amount</th>
                  <th className="px-4 py-3">Ref</th>
                </tr>
              </thead>
              <tbody>
                {(logs ?? []).map((l, i) => (
                  <tr key={i} className={cn("border-t", i % 2 === 1 && "bg-white/40")}>
                    <td className="px-4 py-3 font-mono text-xs text-neutral-600">
                      {l.created_at ? new Date(l.created_at).toLocaleString() : "-"}
                    </td>
                    <td className="px-4 py-3 font-mono text-xs">{l.user_id}</td>
                    <td className="px-4 py-3">{l.meter}</td>
                    <td className="px-4 py-3">{l.amount}</td>
                    <td className="px-4 py-3 text-neutral-600">{l.ref_type ?? "-"}</td>
                  </tr>
                ))}
                {(logs ?? []).length === 0 && (
                  <tr>
                    <td className="px-4 py-4" colSpan={5}>
                      Henüz log yok.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </Table>
        </main>
      </div>
    </div>
  );
}
