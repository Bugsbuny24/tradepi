// app/dashboard/page.tsx
import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";

type Quotas = {
  embed_view_remaining: number;
  widget_load_remaining: number;
  api_call_remaining: number;
  watermark_off_views_remaining: number;
};

type Wallet = {
  api_credits: number;
  embed_credits: number;
  widget_credits: number;
};

export default async function DashboardPage() {
  const user = await requireUser(); // giriş yoksa zaten redirect/throw ediyordur
  const supabase = await createClient();

  // 1) Quotas
  const { data: quotasRow } = await supabase
    .from("user_quotas")
    .select(
      "embed_view_remaining, widget_load_remaining, api_call_remaining, watermark_off_views_remaining"
    )
    .eq("user_id", user.id)
    .maybeSingle();

  // 2) Wallets / credits
  const { data: walletRow } = await supabase
    .from("wallets")
    .select("api_credits, embed_credits, widget_credits")
    .eq("user_id", user.id)
    .maybeSingle();

  // 3) Charts count
  const { count: chartsCount } = await supabase
    .from("charts")
    .select("id", { count: "exact", head: true })
    .eq("user_id", user.id);

  // 4) Usage logs (son 20)
  const { data: logs } = await supabase
    .from("usage_logs")
    .select("meter, amount, ref_type, created_at")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(20);

  const quotas: Quotas = {
    embed_view_remaining: quotasRow?.embed_view_remaining ?? 0,
    widget_load_remaining: quotasRow?.widget_load_remaining ?? 0,
    api_call_remaining: quotasRow?.api_call_remaining ?? 0,
    watermark_off_views_remaining: quotasRow?.watermark_off_views_remaining ?? 0,
  };

  const wallet: Wallet = {
    api_credits: walletRow?.api_credits ?? 0,
    embed_credits: walletRow?.embed_credits ?? 0,
    widget_credits: walletRow?.widget_credits ?? 0,
  };

  const hasAnyCredit =
    quotas.api_call_remaining +
      quotas.embed_view_remaining +
      quotas.widget_load_remaining +
      quotas.watermark_off_views_remaining >
    0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold">Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            Kullanıcı: <span className="font-mono">{user.id}</span>
          </p>
        </div>

        <div className="flex gap-2">
          <Link className="underline" href="/apply">
            Paket / Apply
          </Link>
          <Link className="underline" href="/login">
            Login
          </Link>
        </div>
      </div>

      {!hasAnyCredit && (
        <div className="border rounded p-3 bg-yellow-50 text-yellow-900">
          Kredin/quota’n şu an 0 görünüyor. <b>/apply</b> üzerinden paket ekleyip
          tekrar dene.
        </div>
      )}

      <div className="grid gap-3 md:grid-cols-3">
        <Card title="Charts" value={chartsCount ?? 0} />
        <Card title="API Credits (wallet)" value={wallet.api_credits} />
        <Card title="Embed Credits (wallet)" value={wallet.embed_credits} />
      </div>

      <div className="grid gap-3 md:grid-cols-4">
        <Card title="API calls remaining" value={quotas.api_call_remaining} />
        <Card title="Embed views remaining" value={quotas.embed_view_remaining} />
        <Card
          title="Widget loads remaining"
          value={quotas.widget_load_remaining}
        />
        <Card
          title="Watermark-off views remaining"
          value={quotas.watermark_off_views_remaining}
        />
      </div>

      <div className="border rounded p-4">
        <h2 className="font-semibold mb-2">Son kullanım logları</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-3">Zaman</th>
                <th className="py-2 pr-3">Meter</th>
                <th className="py-2 pr-3">Amount</th>
                <th className="py-2 pr-3">Ref</th>
              </tr>
            </thead>
            <tbody>
              {(logs ?? []).map((l, i) => (
                <tr key={i} className="border-b last:border-0">
                  <td className="py-2 pr-3 font-mono">
                    {new Date(l.created_at).toLocaleString()}
                  </td>
                  <td className="py-2 pr-3">{l.meter}</td>
                  <td className="py-2 pr-3">{l.amount}</td>
                  <td className="py-2 pr-3 text-muted-foreground">
                    {l.ref_type ?? "-"}
                  </td>
                </tr>
              ))}
              {(logs ?? []).length === 0 && (
                <tr>
                  <td className="py-2" colSpan={4}>
                    Henüz log yok.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function Card({ title, value }: { title: string; value: number }) {
  return (
    <div className="border rounded p-4">
      <div className="text-sm text-muted-foreground">{title}</div>
      <div className="text-2xl font-semibold">{value}</div>
    </div>
  );
}
